# Original legacy uws for Node.js 14

* Legacy uWebSockets v0.14.8 (newer versions are available; v0.15, v0.16, v0.17, v18 and finally v19)
* Addon from 2018 made compatible with Node.js 14
* SSL is probably broken
